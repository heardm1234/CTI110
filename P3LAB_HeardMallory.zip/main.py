def is_leap_year(user_year):
    if (user_year % 4 == 0) and (user_year % 100 != 0):
        print('{:d} - leap year'.format(user_year))
        return True
    elif (user_year % 400 == 0) and (user_year % 100 == 0):
        print('{:d} - leap year'.format(user_year))
        return True
    else:
        print('{:d} - not a leap year'.format(user_year))
        return False

if __name__ == '__main__':
    user_year = int(input())
    is_leap_year(user_year)