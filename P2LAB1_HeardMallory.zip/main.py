#driving_cost() function
def driving_cost(driven_miles, miles_per_gallon, dollars_per_gallon):
    dm = miles_per_gallon / dollars_per_gallon
    gc = driven_miles / dm
    return gc
    
#Driver code
if __name__ == '__main__':
    #get input for gas efficiency
    gas_efficiency = float(input())
    #get input for gas cost
    gas_cost = float(input())
    
    #output the gas cost for 20 miles, 75 miles, and 500 miles
    print(f'{driving_cost(20, gas_efficiency, gas_cost):.2f} {driving_cost(75, gas_efficiency, gas_cost):.2f} {driving_cost(500, gas_efficiency, gas_cost):.2f}')